# Deployment Guide for Saints Barbers Website

## GitHub Repository Setup

### 1. Create GitHub Repository

1. Go to [GitHub](https://github.com) and sign in
2. Click "New repository" 
3. Name it `saints-barbers-website`
4. Add description: "Professional barbershop website with booking system"
5. Set to Public or Private as preferred
6. Don't initialize with README (we have one)
7. Click "Create repository"

### 2. Upload Files to GitHub

**Option A: Using GitHub Web Interface**
1. On your new repository page, click "uploading an existing file"
2. Drag and drop these files/folders:
   - `app.py`
   - `main.py` 
   - `models.py`
   - `README.md`
   - `.gitignore`
   - `static/` folder (with all contents)
   - `templates/` folder (with all contents)
3. Commit with message: "Initial commit - Saints Barbers website"

**Option B: Using Git Commands**
```bash
git init
git add .
git commit -m "Initial commit - Saints Barbers website"
git branch -M main
git remote add origin https://github.com/yourusername/saints-barbers-website.git
git push -u origin main
```

### 3. Create Requirements File

Since the system requirements file can't be edited, create a new one for GitHub:

Create `dependencies.txt` with:
```
email-validator==2.1.0
flask==3.0.0
flask-sqlalchemy==3.1.1
gunicorn==21.2.0
psycopg2-binary==2.9.9
werkzeug==3.0.1
```

## Deployment Options

### Option 1: Replit (Recommended for Easy Setup)

1. Import from GitHub in Replit
2. Set environment variables in Secrets tab:
   - `DATABASE_URL`
   - `SESSION_SECRET`
3. Run with: `gunicorn --bind 0.0.0.0:5000 main:app`

### Option 2: Heroku

1. Create Heroku app
2. Connect to GitHub repository
3. Add PostgreSQL addon
4. Set config vars for environment variables
5. Deploy from main branch

### Option 3: DigitalOcean App Platform

1. Create new app from GitHub
2. Configure build and run commands
3. Add database component
4. Set environment variables

### Option 4: Railway

1. Connect GitHub repository
2. Add PostgreSQL database
3. Set environment variables
4. Deploy automatically

## Environment Variables Required

For any deployment platform, set these environment variables:

```
DATABASE_URL=postgresql://user:password@host:port/database
SESSION_SECRET=your-secure-random-string
FLASK_ENV=production
```

## Database Setup

Most cloud platforms provide managed PostgreSQL. The application will automatically create tables on first run.

## Custom Domain (Optional)

After deployment, you can connect a custom domain like `saintsbarbers.com` through your hosting platform's domain settings.

## Maintenance

- Monitor application logs for errors
- Regular database backups
- Update dependencies periodically
- Monitor booking system functionality