from app import db
from datetime import datetime


class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    rating = db.Column(db.Integer, nullable=False)  # 1-5 stars
    review_text = db.Column(db.Text, nullable=False)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)
    approved = db.Column(db.Boolean, default=False)  # For moderation

    def __repr__(self):
        return f'<Review {self.name}: {self.rating} stars>'


class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    service = db.Column(db.String(100), nullable=False)
    staff_member = db.Column(db.String(100), nullable=False)
    booking_date = db.Column(db.Date, nullable=False)
    booking_time = db.Column(db.Time, nullable=False)
    duration_minutes = db.Column(db.Integer, nullable=False)  # Service duration
    end_time = db.Column(db.Time, nullable=False)  # Calculated end time
    date_created = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='pending')  # pending, confirmed, completed, cancelled

    def __repr__(self):
        return f'<Booking {self.name}: {self.service} on {self.booking_date} at {self.booking_time}>'


class StaffSchedule(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    staff_member = db.Column(db.String(100), nullable=False)
    day_of_week = db.Column(db.Integer, nullable=False)  # 0=Monday, 6=Sunday
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    is_available = db.Column(db.Boolean, default=True)

    def __repr__(self):
        return f'<Schedule {self.staff_member}: Day {self.day_of_week}>'


class ServiceDuration(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    service_name = db.Column(db.String(100), nullable=False, unique=True)
    duration_minutes = db.Column(db.Integer, nullable=False)
    price = db.Column(db.String(10), nullable=False)

    def __repr__(self):
        return f'<Service {self.service_name}: {self.duration_minutes}min>'