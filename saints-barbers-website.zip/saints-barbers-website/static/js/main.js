// ===== Main JavaScript for Saints Barbers Website ===== //

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Feather Icons
    if (typeof feather !== 'undefined') {
        feather.replace();
    }
    
    // Initialize all functionality
    initDarkMode();
    initBookingForm();
    initGalleryLightbox();
    initFlashMessages();
    initSmoothScrolling();
    initFormValidation();
    
    // Remove complex staff navigation - let browser handle it naturally
});

// ===== Dark Mode Toggle ===== //
function initDarkMode() {
    const darkModeToggle = document.getElementById('darkModeToggle');
    const body = document.body;
    
    // Check for saved dark mode preference
    const isDarkMode = localStorage.getItem('darkMode') === 'true';
    
    if (isDarkMode) {
        body.classList.add('dark-mode');
        darkModeToggle.checked = true;
    }
    
    // Toggle dark mode
    darkModeToggle.addEventListener('change', function() {
        body.classList.toggle('dark-mode');
        localStorage.setItem('darkMode', body.classList.contains('dark-mode'));
    });
}

// ===== Booking Form Functionality ===== //
function initBookingForm() {
    const startBookingBtn = document.getElementById('startBooking');
    const bookingForm = document.getElementById('bookingForm');
    const serviceSelect = document.getElementById('service');
    const staffSelect = document.getElementById('staff-select');
    const dateInput = document.getElementById('date');
    const timeInput = document.getElementById('time');
    
    // Business hours configuration
    const businessHours = {
        0: null, // Sunday - closed
        1: ['09:00', '18:30'], // Monday
        2: ['09:00', '18:30'], // Tuesday
        3: ['09:00', '18:30'], // Wednesday
        4: ['09:00', '18:30'], // Thursday
        5: ['09:00', '19:00'], // Friday
        6: ['09:00', '18:00']  // Saturday
    };
    
    // Start booking button click
    if (startBookingBtn) {
        startBookingBtn.addEventListener('click', function() {
            startBookingBtn.style.display = 'none';
            bookingForm.style.display = 'block';
            document.getElementById('step-service').style.display = 'block';
        });
    }
    
    // Set minimum date to today
    if (dateInput) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.min = today;
        
        // Validate date selection
        dateInput.addEventListener('change', function() {
            validateDateTime();
        });
    }
    
    // Validate time selection
    if (timeInput) {
        timeInput.addEventListener('change', function() {
            validateDateTime();
        });
    }
    
    // Service selection change
    if (serviceSelect) {
        serviceSelect.addEventListener('change', function() {
            updateAvailableSlots();
        });
    }
    
    // Staff selection change
    const staffSelect = document.getElementById('staff-select');
    if (staffSelect) {
        staffSelect.addEventListener('change', function() {
            updateAvailableSlots();
        });
    }
    
    // Date selection change
    if (dateInput) {
        dateInput.addEventListener('change', function() {
            updateAvailableSlots();
        });
    }
    
    function updateAvailableSlots() {
        const service = serviceSelect.value;
        const staff = staffSelect.value;
        const date = dateInput.value;
        
        if (!service || !staff || !date) {
            return;
        }
        
        // Fetch available time slots
        fetch(`/get_available_slots?service=${encodeURIComponent(service)}&staff=${encodeURIComponent(staff)}&date=${encodeURIComponent(date)}`)
            .then(response => response.json())
            .then(slots => {
                updateTimeOptions(slots);
            })
            .catch(error => {
                console.error('Error fetching available slots:', error);
            });
    }
    
    function updateTimeOptions(availableSlots) {
        if (!timeInput) return;
        
        // Clear existing options
        timeInput.innerHTML = '<option value="">Select a time</option>';
        
        if (availableSlots.length === 0) {
            const option = document.createElement('option');
            option.value = '';
            option.textContent = 'No available slots';
            option.disabled = true;
            timeInput.appendChild(option);
            return;
        }
        
        // Add available time slots
        availableSlots.forEach(slot => {
            const option = document.createElement('option');
            option.value = slot;
            option.textContent = slot;
            timeInput.appendChild(option);
        });
    }
    
    function validateDateTime() {
        const selectedDate = dateInput.value;
        const selectedTime = timeInput.value;
        const timeWarning = document.getElementById('time-warning');
        
        if (!selectedDate || !selectedTime) return;
        
        const date = new Date(selectedDate);
        const dayOfWeek = date.getDay();
        const hours = businessHours[dayOfWeek];
        
        // Check if closed on selected day
        if (!hours) {
            if (timeWarning) {
                timeWarning.textContent = 'We are closed on Sundays. Please select another day.';
                timeWarning.style.display = 'block';
            }
            timeInput.setCustomValidity('Closed on Sundays');
            return;
        }
        
        // Check if time is within business hours
        const [openTime, closeTime] = hours;
        const selectedTimeMinutes = timeToMinutes(selectedTime);
        const openTimeMinutes = timeToMinutes(openTime);
        const closeTimeMinutes = timeToMinutes(closeTime);
        
        // Account for service duration
        const selectedService = serviceSelect.options[serviceSelect.selectedIndex];
        const serviceDuration = parseInt(selectedService?.dataset?.duration || 0);
        const endTimeMinutes = selectedTimeMinutes + serviceDuration;
        
        if (selectedTimeMinutes < openTimeMinutes || endTimeMinutes > closeTimeMinutes) {
            if (timeWarning) {
                timeWarning.textContent = `Please select a time between ${openTime} and ${closeTime} (accounting for service duration).`;
                timeWarning.style.display = 'block';
                timeWarning.style.color = 'hsl(0 0% 20%)'; // Dark gray instead of red
            }
            timeInput.setCustomValidity('Outside business hours');
        } else {
            if (timeWarning) {
                timeWarning.style.display = 'none';
            }
            timeInput.setCustomValidity('');
        }
    }
    
    function timeToMinutes(timeString) {
        const [hours, minutes] = timeString.split(':').map(Number);
        return hours * 60 + minutes;
    }
}

// ===== Step Navigation Functions ===== //
function nextStep(stepId) {
    // Validate current step before proceeding
    const currentStep = document.querySelector('.booking-step[style*="block"]');
    if (currentStep && !validateCurrentStep(currentStep)) {
        return;
    }
    
    // Hide all steps
    document.querySelectorAll('.booking-step').forEach(step => {
        step.style.display = 'none';
    });
    
    // Show target step
    const targetStep = document.getElementById(stepId);
    if (targetStep) {
        targetStep.style.display = 'block';
        
        // Update summary if we're on the final step
        if (stepId === 'step-details') {
            updateBookingSummary();
        }
    }
}

function prevStep(stepId) {
    // Hide all steps
    document.querySelectorAll('.booking-step').forEach(step => {
        step.style.display = 'none';
    });
    
    // Show target step
    const targetStep = document.getElementById(stepId);
    if (targetStep) {
        targetStep.style.display = 'block';
    }
}

function validateCurrentStep(step) {
    const inputs = step.querySelectorAll('input[required], select[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.style.borderColor = 'hsl(0 0% 20%)'; // Dark gray instead of red
            isValid = false;
        } else {
            input.style.borderColor = '';
        }
    });
    
    if (!isValid) {
        showNotification('Please fill in all required fields.', 'error');
    }
    
    return isValid;
}

function updateBookingSummary() {
    const service = document.getElementById('service').value;
    const staff = document.getElementById('staff-select').value;
    const date = document.getElementById('date').value;
    const time = document.getElementById('time').value;
    const summaryContent = document.getElementById('summary-content');
    
    if (summaryContent) {
        const formattedDate = new Date(date).toLocaleDateString('en-GB', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        
        const selectedService = document.getElementById('service').options[document.getElementById('service').selectedIndex];
        const serviceDuration = selectedService?.dataset?.duration || 'N/A';
        
        summaryContent.innerHTML = `
            <p><strong>Service:</strong> ${service}</p>
            <p><strong>Duration:</strong> ${serviceDuration} minutes</p>
            <p><strong>Barber:</strong> ${staff}</p>
            <p><strong>Date:</strong> ${formattedDate}</p>
            <p><strong>Time:</strong> ${time}</p>
        `;
    }
}

// ===== Gallery Lightbox ===== //
function initGalleryLightbox() {
    // This function is called when gallery items are clicked
    window.openLightbox = function(imageSrc) {
        const lightbox = document.getElementById('lightbox');
        const lightboxImg = document.getElementById('lightbox-img');
        
        if (lightbox && lightboxImg) {
            lightboxImg.src = imageSrc;
            lightbox.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
    };
    
    window.closeLightbox = function() {
        const lightbox = document.getElementById('lightbox');
        if (lightbox) {
            lightbox.style.display = 'none';
            document.body.style.overflow = '';
        }
    };
    
    // Close lightbox on Escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            window.closeLightbox();
        }
    });
}

// ===== Flash Messages ===== //
function initFlashMessages() {
    // Auto-hide flash messages after 5 seconds
    const flashMessages = document.querySelectorAll('.flash-message');
    
    flashMessages.forEach(message => {
        setTimeout(() => {
            message.style.animation = 'slideOut 0.3s ease-out forwards';
            setTimeout(() => {
                message.remove();
            }, 300);
        }, 5000);
    });
}

// Add CSS for slide out animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideOut {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(100%);
        }
    }
`;
document.head.appendChild(style);

// ===== Smooth Scrolling ===== //
function initSmoothScrolling() {
    const navLinks = document.querySelectorAll('a[href^="#"]');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                const headerOffset = 100;
                const elementPosition = targetElement.offsetTop;
                const offsetPosition = elementPosition - headerOffset;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
                
                // Add visual feedback
                targetElement.style.transition = 'background-color 0.3s ease';
                targetElement.style.backgroundColor = 'rgba(255, 215, 0, 0.1)';
                setTimeout(() => {
                    targetElement.style.backgroundColor = '';
                }, 1000);
            } else {
                console.log('Target element not found:', targetId);
            }
        });
    });
}

// ===== Form Validation ===== //
function initFormValidation() {
    const form = document.getElementById('bookingForm');
    
    if (form) {
        form.addEventListener('submit', function(event) {
            const inputs = form.querySelectorAll('input[required], select[required]');
            let isValid = true;
            
            inputs.forEach(input => {
                if (!input.value.trim()) {
                    input.style.borderColor = 'hsl(0 0% 20%)'; // Dark gray instead of red
                    isValid = false;
                } else {
                    input.style.borderColor = '';
                }
            });
            
            // Validate phone number
            const phoneInput = document.getElementById('phone');
            if (phoneInput && phoneInput.value) {
                const phoneRegex = /^[\+]?[0-9\s\-\(\)]{10,}$/;
                if (!phoneRegex.test(phoneInput.value)) {
                    phoneInput.style.borderColor = 'hsl(0 0% 20%)'; // Dark gray instead of red
                    isValid = false;
                    showNotification('Please enter a valid phone number.', 'error');
                }
            }
            
            if (!isValid) {
                event.preventDefault();
                showNotification('Please correct the highlighted fields.', 'error');
            }
        });
    }
}

// ===== Utility Functions ===== //
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `flash-message flash-${type}`;
    notification.innerHTML = `
        <span>${message}</span>
        <button class="flash-close" onclick="this.parentElement.remove()">&times;</button>
    `;
    
    let container = document.querySelector('.flash-messages');
    if (!container) {
        container = document.createElement('div');
        container.className = 'flash-messages';
        document.body.appendChild(container);
    }
    
    container.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-out forwards';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 5000);
}

// ===== Global Functions (exposed to window for HTML onclick handlers) ===== //
window.nextStep = nextStep;
window.prevStep = prevStep;
