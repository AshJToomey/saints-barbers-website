import os
import logging
from flask import Flask, render_template, request, redirect, flash, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from datetime import datetime

# Set up logging
logging.basicConfig(level=logging.DEBUG)


class Base(DeclarativeBase):
    pass


db = SQLAlchemy(model_class=Base)
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "your_fallback_secret_key_for_development")

# configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL") or "sqlite:///barbershop.db"
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
# initialize the app with the extension
db.init_app(app)

with app.app_context():
    # Make sure to import the models here or their tables won't be created
    import models  # noqa: F401
    db.create_all()

@app.route('/')
def home():
    """Main homepage route"""
    from models import Review
    # Get approved reviews for display
    reviews = Review.query.filter_by(approved=True).order_by(Review.date_created.desc()).limit(6).all()
    # Initialize service durations if empty
    initialize_services()
    return render_template('index.html', reviews=reviews)

@app.route('/book', methods=['POST'])
def book():
    """Handle booking form submission"""
    try:
        from models import Booking, ServiceDuration
        from datetime import timedelta
        
        # Get form data
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        phone = request.form.get('phone', '').strip()
        service = request.form.get('service', '').strip()
        staff = request.form.get('staff', '').strip()
        date_str = request.form.get('date', '').strip()
        time_str = request.form.get('time', '').strip()

        # Validate required fields
        if not all([name, phone, service, staff, date_str, time_str]):
            flash("Please fill in all required fields.", "error")
            return redirect(url_for('home'))

        # Parse date and time
        try:
            booking_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            booking_time = datetime.strptime(time_str, '%H:%M').time()
        except ValueError:
            flash("Invalid date or time format.", "error")
            return redirect(url_for('home'))

        # Get service duration
        service_duration = ServiceDuration.query.filter_by(service_name=service).first()
        if not service_duration:
            flash("Invalid service selected.", "error")
            return redirect(url_for('home'))

        # Calculate end time
        start_datetime = datetime.combine(booking_date, booking_time)
        end_datetime = start_datetime + timedelta(minutes=service_duration.duration_minutes)
        end_time = end_datetime.time()

        # Check for conflicts
        existing_booking = Booking.query.filter_by(
            staff_member=staff,
            booking_date=booking_date,
            booking_time=booking_time
        ).first()

        if existing_booking:
            flash(f"{staff} is already booked at that time. Please choose a different time.", "error")
            return redirect(url_for('home'))

        # Create new booking
        booking = Booking(
            name=name,
            email=email or '',
            phone=phone,
            service=service,
            staff_member=staff,
            booking_date=booking_date,
            booking_time=booking_time,
            duration_minutes=service_duration.duration_minutes,
            end_time=end_time
        )

        db.session.add(booking)
        db.session.commit()

        flash("Your booking has been confirmed! We'll be in touch soon.", "success")
        app.logger.info(f"New booking: {name}, {phone}, {service}, {staff}, {date_str}, {time_str}")

        # Also save to text file for backup
        with open('bookings.txt', 'a') as f:
            f.write(f"{name}, {phone}, {service}, {staff}, {date_str}, {time_str}\n")

    except Exception as e:
        app.logger.error(f"Booking error: {str(e)}")
        flash("An error occurred while processing your booking. Please try again.", "error")

    return redirect(url_for('home'))


def initialize_services():
    """Initialize service durations in database"""
    from models import ServiceDuration
    
    if ServiceDuration.query.count() == 0:
        services = [
            # Popular Services
            ("Standard Cut", 30, "£20"),
            ("Skin Fade", 45, "£24"),
            ("Skin Fade & Beard Trim", 55, "£35"),
            
            # Standard Cuts
            ("Standard Cut & Beard Trim", 45, "£28"),
            ("Standard Cut, Beard & Wash", 55, "£32"),
            ("Haircut & Shave With Hot Towel", 60, "£40"),
            ("Standard Cut & Wash", 35, "£24"),
            ("Senior Citizen", 20, "£13"),
            
            # Skin Fades
            ("Skin Taper Fade", 40, "£24"),
            ("Skin Fade & Wash", 50, "£28"),
            ("Skin Fade, Beard & Wash", 55, "£38"),
            
            # Buzz Cuts
            ("Buzz Cut", 20, "£15"),
            ("Buzz Cut & Beard", 30, "£22"),
            ("Buzz Cut & Wash", 25, "£18"),
            
            # Kids Cuts
            ("Kids Cut (up to 13 years old)", 30, "£16"),
            ("Kids Skin Fade", 35, "£20"),
            ("Kids Cut & Wash", 30, "£20"),
            
            # Open Razor Shave
            ("Head Shave & Razor", 25, "£18"),
            ("Razor Shave & Hot Towel", 30, "£20"),
            
            # Beard Services
            ("Beard Trim & Shape", 20, "£13"),
            ("Beard Trim, Shape & Hot Towel Treatment", 25, "£18"),
        ]
        
        for service_name, duration, price in services:
            service = ServiceDuration(
                service_name=service_name,
                duration_minutes=duration,
                price=price
            )
            db.session.add(service)
        
        db.session.commit()


@app.route('/get_available_slots')
def get_available_slots():
    """Get available time slots for a specific staff member and date"""
    from models import Booking, ServiceDuration
    import json
    from datetime import timedelta, time
    
    staff_member = request.args.get('staff')
    date_str = request.args.get('date')
    service = request.args.get('service')
    
    if not all([staff_member, date_str, service]):
        return json.dumps([])
    
    try:
        booking_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        day_of_week = booking_date.weekday()  # 0=Monday, 6=Sunday
        
        # Define business hours
        business_hours = {
            0: (time(9, 0), time(18, 30)),   # Monday
            1: (time(9, 0), time(18, 30)),   # Tuesday
            2: (time(9, 0), time(18, 30)),   # Wednesday
            3: (time(9, 0), time(18, 30)),   # Thursday
            4: (time(9, 0), time(19, 0)),    # Friday
            5: (time(9, 0), time(18, 0)),    # Saturday
        }
        
        # Check if closed on Sunday
        if day_of_week == 6:
            return json.dumps([])
        
        start_time, end_time = business_hours[day_of_week]
        
        # Get service duration
        service_duration = ServiceDuration.query.filter_by(service_name=service).first()
        if not service_duration:
            return json.dumps([])
        
        duration_minutes = service_duration.duration_minutes
        
        # Get existing bookings for this staff member on this date
        existing_bookings = Booking.query.filter_by(
            staff_member=staff_member,
            booking_date=booking_date
        ).all()
        
        # Generate all possible time slots (15-minute intervals)
        available_slots = []
        current_time = start_time
        
        while current_time < end_time:
            # Calculate end time for this slot
            current_datetime = datetime.combine(booking_date, current_time)
            slot_end_datetime = current_datetime + timedelta(minutes=duration_minutes)
            slot_end_time = slot_end_datetime.time()
            
            # Check if slot fits within business hours
            if slot_end_time <= end_time:
                # Check for conflicts with existing bookings
                slot_available = True
                for booking in existing_bookings:
                    booking_start = booking.booking_time
                    booking_end = booking.end_time
                    
                    # Check if there's overlap (with 10-minute buffer)
                    if (current_time < booking_end and slot_end_time > booking_start):
                        slot_available = False
                        break
                
                if slot_available:
                    available_slots.append(current_time.strftime('%H:%M'))
            
            # Move to next 15-minute slot
            current_datetime = datetime.combine(booking_date, current_time)
            next_datetime = current_datetime + timedelta(minutes=15)
            current_time = next_datetime.time()
        
        return json.dumps(available_slots)
        
    except Exception as e:
        app.logger.error(f"Error getting available slots: {str(e)}")
        return json.dumps([])


@app.route('/submit_review', methods=['POST'])
def submit_review():
    """Handle review form submission"""
    try:
        from models import Review
        
        # Extract form data
        name = request.form.get('review_name', '').strip()
        rating = request.form.get('rating')
        review_text = request.form.get('review_text', '').strip()
        
        # Validate required fields
        if not all([name, rating, review_text]):
            flash("Please fill in all fields to submit your review.", "error")
            return redirect(url_for('home'))
        
        # Validate rating
        try:
            rating = int(rating)
            if rating < 1 or rating > 5:
                flash("Please select a rating between 1 and 5 stars.", "error")
                return redirect(url_for('home'))
        except ValueError:
            flash("Please select a valid rating.", "error")
            return redirect(url_for('home'))
        
        # Create new review
        review = Review(
            name=name,
            rating=rating,
            review_text=review_text,
            approved=False  # Reviews need approval before showing
        )
        
        db.session.add(review)
        db.session.commit()
        
        flash("Thank you for your review! It will be published after approval.", "success")
        app.logger.info(f"New review submitted: {name}, {rating} stars")
        
    except Exception as e:
        app.logger.error(f"Review submission error: {str(e)}")
        flash("There was an error submitting your review. Please try again.", "error")
        
    return redirect(url_for('home'))


@app.route('/admin/bookings')
def admin_bookings():
    """Admin dashboard to view all bookings"""
    from models import Booking
    from sqlalchemy import and_
    
    # Get filter parameters
    date_filter = request.args.get('date')
    staff_filter = request.args.get('staff')
    
    # Base query
    query = Booking.query
    
    # Apply filters
    if date_filter:
        try:
            filter_date = datetime.strptime(date_filter, '%Y-%m-%d').date()
            query = query.filter(Booking.booking_date == filter_date)
        except ValueError:
            pass
    
    if staff_filter:
        query = query.filter(Booking.staff_member == staff_filter)
    
    # Get bookings ordered by date and time
    bookings = query.order_by(Booking.booking_date, Booking.booking_time).all()
    
    # Get unique staff members for filter dropdown
    staff_members = ['Alex Neophytou', 'Big Mike', 'Kaya', 'Mike Nicodemou', 'Tolga']
    
    return render_template('admin_bookings.html', 
                         bookings=bookings, 
                         staff_members=staff_members,
                         selected_date=date_filter,
                         selected_staff=staff_filter)


@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return render_template('index.html'), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    app.logger.error(f"Internal error: {str(error)}")
    flash("An internal error occurred. Please try again later.", "error")
    return render_template('index.html'), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
